<?php
class DB {
    public static function connect() {
        return new PDO(
            "mysql:host=".Config::get('DB_HOST').";dbname=".Config::get('DB_NAME'),
            Config::get('DB_USER'),
            Config::get('DB_PASS'),
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
    }
}
