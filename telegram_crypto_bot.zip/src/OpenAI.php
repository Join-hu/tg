<?php
class OpenAI {
    public function chat($messages) {
        $ch = curl_init("https://api.openai.com/v1/chat/completions");

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer ".Config::get('OPENAI_API_KEY'),
                "Content-Type: application/json"
            ],
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode([
                "model"=>"gpt-4o-mini",
                "messages"=>$messages
            ])
        ]);

        $res = curl_exec($ch);
        curl_close($ch);

        $json = json_decode($res, true);

        return $json['choices'][0]['message']['content'] ?? "Ошибка";
    }
}
