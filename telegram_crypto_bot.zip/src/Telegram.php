<?php
class Telegram {
    private $token;

    public function __construct() {
        $this->token = Config::get('TELEGRAM_TOKEN');
    }

    public function send($chatId, $text) {
        file_get_contents(
            "https://api.telegram.org/bot{$this->token}/sendMessage?" .
            http_build_query(['chat_id'=>$chatId,'text'=>$text])
        );
    }

    public function keyboard($chatId, $text, $buttons) {
        file_get_contents(
            "https://api.telegram.org/bot{$this->token}/sendMessage?" .
            http_build_query([
                'chat_id'=>$chatId,
                'text'=>$text,
                'reply_markup'=>json_encode(['inline_keyboard'=>$buttons])
            ])
        );
    }
}
