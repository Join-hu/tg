<?php
class Config {
    public static function get($key) {
        $env = parse_ini_file(__DIR__ . '/../.env');
        return $env[$key] ?? null;
    }
}
