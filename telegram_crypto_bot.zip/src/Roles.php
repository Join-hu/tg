<?php
class Roles {
    public static function get() {
        return [
            "role"=>"system",
            "content"=>"Ты AI помощник по крипте. Помогаешь зарабатывать без гарантий дохода."
        ];
    }
}
