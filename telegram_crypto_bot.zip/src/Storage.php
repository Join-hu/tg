<?php
class Storage {
    private $pdo;

    public function __construct() {
        $this->pdo = DB::connect();
    }

    public function user($id) {
        $this->pdo->prepare("INSERT IGNORE INTO users(id) VALUES(?)")->execute([$id]);
    }

    public function addMsg($id, $role, $text) {
        $this->pdo->prepare("INSERT INTO messages(chat_id,role,content) VALUES(?,?,?)")
        ->execute([$id,$role,$text]);
    }

    public function getMsgs($id) {
        $stmt = $this->pdo->prepare("
            SELECT role,content FROM messages
            WHERE chat_id=? ORDER BY id DESC LIMIT 10
        ");
        $stmt->execute([$id]);
        return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    public function todayCount($id) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM messages
            WHERE chat_id=? AND DATE(created_at)=CURDATE()
        ");
        $stmt->execute([$id]);
        return $stmt->fetchColumn();
    }
}
