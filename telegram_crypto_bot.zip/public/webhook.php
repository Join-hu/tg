<?php
require "../src/Config.php";
require "../src/DB.php";
require "../src/Telegram.php";
require "../src/OpenAI.php";
require "../src/Storage.php";
require "../src/Roles.php";

$tg = new Telegram();
$ai = new OpenAI();
$db = new Storage();

$update = json_decode(file_get_contents("php://input"), true);

$text = $update['message']['text'] ?? '';
$chatId = $update['message']['chat']['id'] ?? null;

if (!$chatId || !$text) exit;

$db->user($chatId);

if ($db->todayCount($chatId) > 10) {
    $tg->keyboard($chatId, "Лимит 😢", [
        [['text'=>'💰 Заработать','callback_data'=>'earn']],
        [['text'=>'💎 Купить','callback_data'=>'buy']]
    ]);
    exit;
}

if (isset($update['callback_query'])) {
    $data = $update['callback_query']['data'];

    if ($data === 'earn') {
        $tg->keyboard($chatId,
            "🔥 Получи бонус:",
            [[['text'=>'👉 Перейти','url'=>Config::get('AFF_LINK')]]]
        );
        exit;
    }

    if ($data === 'buy') {
        $tg->send($chatId,"💎 Доступ: 199₽/мес");
        exit;
    }
}

$db->addMsg($chatId,'user',$text);
$messages = $db->getMsgs($chatId);

array_unshift($messages, Roles::get());

$reply = $ai->chat($messages);

$db->addMsg($chatId,'assistant',$reply);

$tg->send($chatId, $reply);
